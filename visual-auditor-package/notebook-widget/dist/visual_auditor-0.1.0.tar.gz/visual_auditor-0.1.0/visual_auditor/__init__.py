
"""Top-level package for the visual auditor notebook widget."""

__author__ = """David Munechika"""
__email__ = 'david.munechika@gatech.edu'
__version__ = '0.1.0'

import visual_auditor.visual_auditor